from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
import bcrypt
from django.core.mail import send_mail, BadHeaderError
from .forms import ContactForm

# Create your views here.


def index(request):
    request.session.flush()
    return render(request, "index.html")


def register(request):
    if request.method == "POST":
        errors = User.objects.registration_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/")
        else:
            hashedpassword = bcrypt.hashpw(
                request.POST["password"].encode(), bcrypt.gensalt()
            ).decode()
            newUser = User.objects.create(
                first_name=request.POST["first_name"],
                last_name=request.POST["last_name"],
                birthday=request.POST["birthday"],
                email=request.POST["email"],
                password=hashedpassword,
            )
            # this is where we create a session with the user we just made
            request.session["user_id"] = newUser.id
            request.session["user"] = newUser.first_name
            return redirect('/clothingswap/home')
    else:
        return redirect("/")


def login(request):
    if request.method == "POST":
        errors = User.objects.login_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/")
        else:
            LoggedUser = User.objects.filter(email=request.POST["logemail"])
            request.session["user_id"] = LoggedUser[0].id
            return redirect('/clothingswap/home')
    else:
        return redirect("/")


def home(request):
    if 'user_id' not in request.session:
        return redirect('/')
    current_user = User.objects.filter(id=request.session['user_id'])
    context = {
        'user': current_user[0],
        'swaps': Swap.objects.exclude(status="picked_up"),
        'successful_swaps': Swap.objects.filter(status="picked_up"),
    }
    print(Swap.objects.filter(status="picked_up"))
    return render(request, 'home.html', context)


def logout(request):
    request.session.flush()
    return redirect("/")


def add(request):
    current_user = User.objects.filter(id=request.session['user_id'])
    context = {
        'user': current_user[0],
    }
    if 'user_id' not in request.session:
        return redirect('/')
    return render(request, "new.html", context)


def create(request):
    if request.method == "POST":
        errors = User.objects.swap_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/clothingswap/add")
        else:
            Swap.objects.create(
                clothing_sizes=request.POST["clothing_sizes"],
                number_of_bags=request.POST["number_of_bags"],
                zip_code=request.POST["zip_code"],
                additional_notes=request.POST["additional_notes"],
                added_by=User.objects.get(id=request.session["user_id"]))
            return redirect('/clothingswap/home')
    else:
        return redirect("/clothingswap/home")


def edit(request, id):
    current_user = User.objects.filter(id=request.session['user_id'])
    context = {
        'user': current_user[0],
        "swap": Swap.objects.get(id=id),
    }
    return render(request, 'edit.html', context)


def modify(request, id):
    if request.method == "POST":
        errors = User.objects.swap_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/clothingswap/home")
        else:
            edit_swap = Swap.objects.get(id=id)
            edit_swap.clothing_sizes = request.POST['clothing_sizes']
            edit_swap.zip_code = request.POST['zip_code']
            edit_swap.number_of_bags = request.POST['number_of_bags']
            edit_swap.additional_notes = request.POST["additional_notes"]
            edit_swap.save()
    return redirect('/clothingswap/home')


def claimemail(request, id):
    user_email = Swap.objects.get(id=id)
    if request.method == 'GET':
        form = ContactForm()
    else:
        form = ContactForm(request.POST)
        if form.is_valid():
            subject = form.cleaned_data['subject']
            from_email = form.cleaned_data['from_email']
            message = form.cleaned_data['message']
            destination_email_address = user_email.added_by.email
            try:
                send_mail(subject, message, from_email,
                          [destination_email_address])
            except BadHeaderError:
                return HttpResponse('Invalid header found.')
            return redirect('/clothingswap/emailsuccess')
    return render(request, "claimemail.html", {'form': form})


def emailsuccess(request):
    current_user = User.objects.filter(id=request.session['user_id'])
    context = {
        'user': current_user[0],
    }
    return render(request, 'emailsuccess.html', context)


def pickedup(request, id):
    if 'user_id' not in request.session:
        return redirect('/')
    picked_swap = Swap.objects.get(id=id)
    picked_swap.status = "picked_up"
    picked_swap.save()
    return redirect("/clothingswap/home")


def about_us(request):
    return render(request, 'aboutus.html')
