from django.apps import AppConfig


class SwapAppConfig(AppConfig):
    name = 'swap_app'
