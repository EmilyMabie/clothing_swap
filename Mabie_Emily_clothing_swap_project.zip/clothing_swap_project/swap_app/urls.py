from django.urls import path
from . import views

urlpatterns = [
    path("", views.index),
    path("clothingswap/home", views.home),
    path("register", views.register),
    path("login", views.login),
    path("logout", views.logout),
    path("clothingswap/add", views.add),
    path("clothingswap/create", views.create),
    path("clothingswap/<int:id>", views.edit),
    path("clothingswap/modify/<int:id>", views.modify),
    path("clothingswap/claim/<int:id>", views.claimemail),
    path("clothingswap/pickedup/<int:id>", views.pickedup),
    path("clothingswap/aboutus", views.about_us),
    path("clothingswap/emailsuccess", views.emailsuccess),
]
