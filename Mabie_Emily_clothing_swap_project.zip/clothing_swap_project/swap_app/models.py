from django.db import models
import re

from django.db.models.deletion import CASCADE
import bcrypt
from .models import *
from dateutil.relativedelta import relativedelta
from datetime import date, datetime

# Create your models here.


class UserManager(models.Manager):
    def registration_validator(self, postData):
        errors = {}
        user_birthday = datetime.strptime(postData['birthday'], '%Y-%m-%d')
        if len(postData["first_name"]) < 2:
            errors["first_name"] = "Your first name must be at least 2 characters."
        if len(postData["last_name"]) < 2:
            errors["last_name"] = "Your last name must be at least 2 characters."
        if user_birthday > datetime.today():
            errors["birthday"] = "User birthday must be in the past."
        if user_birthday > datetime.today() - relativedelta(years=13):
            errors["birthday"] = "User must be at least 13 years of age."
        if len(postData["password"]) < 8:
            errors["password"] = "Your password must be at least 8 characters."
        UserRegex = re.compile(
            r"^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$")
        if not UserRegex.match(
            postData["email"]
        ):  # this checks the info in paranthesis against the regex
            errors["email"] = "This is not a valid email address."
        if postData["password"] != postData["password_confirm"]:
            errors["password_confirm"] = "Password does not match."
        if len(User.objects.filter(email=postData["email"])) > 0:
            errors[
                "emailAlreadyExists"
            ] = "That email is already registered to another user."
        return errors

    def login_validator(self, postData):
        errors = {}
        LoginUser = User.objects.filter(
            email=postData["logemail"]
        )  # it's acceptable for a filter to return an empty list
        if len(LoginUser) > 0:
            if bcrypt.checkpw(
                postData["logpassword"].encode(
                ), LoginUser[0].password.encode()
            ):
                print("Password matches!")
            else:
                errors[
                    "logpassword"
                ] = "That email and password combination is incorrect."
        else:
            errors["logemail"] = "There is no account associated with that email user."
        return errors

    def swap_validator(self, postData):
        errors = {}
        if (int(postData["zip_code"])) < 53701:
            errors["zip_code"] = "Swap locations must be within the boundaries of Madison, Wi."
        if (int(postData["zip_code"])) > 53794:
            errors["zip_code"] = "Swap locations must be within the boundaries of Madison, Wi."
        return errors


class User(models.Model):
    first_name = models.CharField(max_length=32)
    last_name = models.CharField(max_length=32)
    birthday = models.DateField()
    email = models.CharField(max_length=60)
    password = models.CharField(
        max_length=80
    )  # this needs extra space because it will be encrypted
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()


class Swap(models.Model):
    clothing_sizes = models.CharField(max_length=10)
    zip_code = models.IntegerField()
    number_of_bags = models.IntegerField()
    additional_notes = models.CharField(max_length=55)
    added_by = models.ForeignKey(
        User, related_name="user_swaps", on_delete=CASCADE)
    status = models.CharField(max_length=12)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
