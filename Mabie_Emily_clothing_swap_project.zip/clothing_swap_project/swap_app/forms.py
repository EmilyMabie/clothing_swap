from django import forms


class ContactForm(forms.Form):
    from_email = forms.EmailField(required=True)
    # to_email =
    subject = forms.CharField(required=True)
    message = forms.CharField(widget=forms.Textarea, required=True)
